import telebot
from telebot import types
from settings import (
    BOT_API_TOKEN,
    DEFAULT_SERVER_ID,
    BLACKLISTED_CHAT_IDS,
    WHITELISTED_CHAT_IDS,
    ENABLE_BLACKLIST,
    ENABLE_WHITELIST,
    ADMIN_IDS
)
import telegram.monitoring as monitoring
import outline.api as outline
from settings import BOT_API_TOKEN, DEFAULT_SERVER_ID, BLACKLISTED_CHAT_IDS
from helpers.exceptions import KeyCreationError, KeyRenamingError, InvalidServerIdError
import telegram.message_formatter as f
from helpers.aliases import ServerId
import sqlite3

MAX_USERS_PER_KEY = 1  # Например, 1 пользователь на ключ

assert BOT_API_TOKEN is not None
bot = telebot.TeleBot(BOT_API_TOKEN, parse_mode='HTML')

# Создание подключения к базе данных
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Создание таблицы users, если она не существует
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        key_name TEXT
    )
''')
conn.commit()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_keys (
        user_id INTEGER,
        key_name TEXT,
        PRIMARY KEY (user_id, key_name),
        FOREIGN KEY (user_id) REFERENCES users (user_id),
        FOREIGN KEY (key_name) REFERENCES users (key_name)
    )
''')
conn.commit()

def authorize(func):
    def wrapper(message):
        chat_id_to_check = message.chat.id

        if ENABLE_BLACKLIST and str(chat_id_to_check) in BLACKLISTED_CHAT_IDS:
            monitoring.report_blacklist_attempt(message.from_user.username, chat_id_to_check)
            return

        if ENABLE_WHITELIST and str(chat_id_to_check) not in WHITELISTED_CHAT_IDS:
            monitoring.report_not_in_whitelist(message.from_user.username, chat_id_to_check)
            return

        return func(message)
    return wrapper

def is_admin(user_id: int) -> bool:
    """Проверяет, является ли пользователь администратором."""
    return user_id in ADMIN_IDS

@bot.message_handler(commands=['status'])
@authorize
def send_status(message):
    monitoring.send_api_status()

@bot.message_handler(commands=['start'])
@authorize
def send_welcome(message):
    bot.send_message(message.chat.id, "Привет, этот бот поможет вернуть доступ к VPN.")

@bot.message_handler(commands=['help'])
@authorize
def send_help(message):
    bot.send_message(message.chat.id, f.make_help_message())

@bot.message_handler(commands=['servers'])
@authorize
def send_servers_list(message):
    bot.send_message(message.chat.id, f.make_servers_list())

@bot.message_handler(content_types=['text'])
@authorize
def anwser(message):
    if message.text == "Получить ключ VPN":
        server_id = DEFAULT_SERVER_ID
        key_name = _form_key_name(message)
        _make_new_key(message, server_id, key_name)

    elif message.text == "Скачать клиент VPN":
        bot.send_message(message.chat.id, f.make_download_message(), disable_web_page_preview=True)

    elif message.text == "FAQ":
        bot.send_message(message.chat.id, f.make_help_message())

    elif message.text == "Мой ключ":
        show_key(message)

    elif message.text[:7] == "/newkey":
        server_id, key_name = _parse_the_command(message)
        _make_new_key(message, server_id, key_name)

    else:
        bot.send_message(message.chat.id, "Unknown command.", reply_markup=_make_main_menu_markup(message))

def get_users_for_key(key_name: str) -> list:
    """Возвращает список пользователей, использующих заданный ключ."""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('SELECT user_id FROM user_keys WHERE key_name = ?', (key_name,))
    users = [row[0] for row in cursor.fetchall()]
    conn.close()
    return users

def remove_user_from_key(user_id: int, key_name: str) -> None:
    """Удаляет пользователя из списка пользователей, использующих заданный ключ."""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM user_keys WHERE user_id = ? AND key_name = ?', (user_id, key_name))
    conn.commit()
    conn.close()

def _make_new_key(message, server_id: ServerId, key_name: str):
    user_id = message.chat.id

    # Отладочное сообщение
    print(f"Пользователь {user_id} пытается получить ключ {key_name}")

    try:
        # Попытка получить ключ с сервера Outline
        key = outline.get_key(key_name, DEFAULT_SERVER_ID)

        # Проверка количества пользователей
        users = get_users_for_key(key_name)
        print(f"Пользователи для ключа {key_name}: {users}") # Отладочное сообщение

        if len(users) >= MAX_USERS_PER_KEY:
            bot.send_message(message.chat.id, "К сожалению, количество пользователей, использующих этот ключ, превышает лимит.")
            return

        # Подключение к базе данных
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()

        # Сохранение информации о пользователе и ключе в базе данных
        cursor.execute('INSERT INTO users (user_id, key_name) VALUES (?, ?)', (user_id, key.kid))
        cursor.execute('INSERT INTO user_keys (user_id, key_name) VALUES (?, ?)', (user_id, key.kid))
        conn.commit()
        conn.close()

        _send_key(message, key, server_id)

    except KeyError:
        # Ключ не найден на сервере, удаляем его из таблицы user_keys
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('DELETE FROM user_keys WHERE user_id = ? AND key_name = ?', (user_id, key_name))
        conn.commit()
        conn.close()
        bot.send_message(message.chat.id, "Ваш старый ключ был удален. Получен новый.")
        # Попытка получить новый ключ с новым именем
        new_key_name = f"{key_name}_{user_id}"
        _make_new_key(message, server_id, new_key_name)
        return

    except KeyCreationError:
        error_message = "API error: cannot create the key"
        _send_error_message(message, error_message)

    except KeyRenamingError:
        error_message = "API error: cannot rename the key"
        _send_error_message(message, error_message)

    except InvalidServerIdError:
        message_to_send = "The server id does not exist."
        bot.send_message(message.chat.id, message_to_send)

def _send_key(message, key, server_id):
    text = f.make_message_for_new_key("outline", key.access_url, server_id)
    warning_text = "\n\n⚠️ Внимание! Передача ключа третьим лицам аннулирует его действие."
    text += warning_text
    text += "\n\nЛимит трафика: 50 ГБ" # Добавляем информацию о лимите трафика

    bot.send_message(message.chat.id, text)
    monitoring.new_key_created(key.kid, key.name, message.chat.id, server_id)

def _send_error_message(message, error_message):
    bot.send_message(message.chat.id, error_message)
    monitoring.send_error(error_message, message.from_user.username, message.chat.id)

def _make_main_menu_markup(message) -> types.ReplyKeyboardMarkup:
    menu_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)

    keygen_server1_button = types.KeyboardButton("Получить ключ VPN")
    download_button = types.KeyboardButton("Скачать клиент VPN")
    help_button = types.KeyboardButton("FAQ")
    show_key_button = types.KeyboardButton("Мой ключ")

    menu_markup.add(keygen_server1_button, download_button, help_button, show_key_button)

    return menu_markup

def _parse_the_command(message) -> list:
    arguments = message.text[8:].split()

    if arguments:
        server_id = arguments[0]
    else:
        server_id = DEFAULT_SERVER_ID

    key_name = ''.join(arguments[1:])

    if not key_name:
        key_name = _form_key_name(message)

    return [server_id, key_name]

def _form_key_name(message) -> str:
    key_name = message.from_user.username
    return key_name

def show_key(message):
    user_id = message.chat.id
    # Подключение к базе данных
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Получение ключа пользователя из базы данных
    cursor.execute('SELECT key_name FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()

    if result:
        key_name = result[0]
        try:
            # Попытка получить ключ с сервера Outline
            key = outline.get_key(key_name, DEFAULT_SERVER_ID)
            bot.send_message(message.chat.id, f.make_message_for_new_key("outline", key.access_url, DEFAULT_SERVER_ID))
        except KeyError:
            bot.send_message(message.chat.id, "Ваш ключ был удален с сервера. Пожалуйста, запросите новый ключ.")
        except Exception as e:
            bot.send_message(message.chat.id, f"Произошла ошибка: {e}")
    else:
        bot.send_message(message.chat.id, "У вас нет ключа VPN.")

def start_telegram_server():
    monitoring.send_start_message()
    bot.infinity_polling()
