import telegram.server

telegram.server.start_telegram_server()
