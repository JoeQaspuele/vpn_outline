AccessUrl = str
KeyId = str
StatusCode = str
UserCommand = str
ServerId = str
